<?php
include_once "class.curl.php";
class gateway extends cURL
{

var $error;
var $data;
	public function getLastError()
	{
		return $this->error;
		
	}
	public function setError($error)
	{
		$this->error=$error;
	}
	
	public function setData($data,$value)
	{
		$this->data[$data]=$value;
	}
	public function getData($data)
	{
		return $this->data[$data];
	}
	
	public function checkConnectivity()
	{
		$address=$this->gatewayAddress;
		echo "Checking connectivity to $address ... \n<br/>";
		$out=$this->post("$address","1=1");
		if(strlen($out)>10)
		{
			echo "<h1>Connection successful...<a href='javascript:void(0);' onClick='document.getElementById(\"contents\").style.display=\"\";return false;'>Show output</a> </h1><br /><br /><br /><br /><div id=\"contents\" style=\"display:none;background-color:green;\">$out</div>";
		}
		else
		{
			echo '<h1>Connection error ?... <a href="javascript:void(0);document.getElementById(\'contents\').style.display=\'\';" onClick=\'document.getElementById("contents").style.display="";return false;\'>Show output</a></h1>You might need to specify a proxy using $smsapp->setProxy()<br /><br /><br /><br /><div id="contents" style="display:none;background-color:red;">'.$out."</div>";
		}
	}
	
	
}




?>