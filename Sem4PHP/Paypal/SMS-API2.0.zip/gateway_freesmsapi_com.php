<?php

include_once "class.gateway.php";
class gateway_freesmsapi_com extends gateway
{
	var $skey;
	var $senderid;
		var $gatewayAddress;
	
	function __construct($params)
	{
	$this->gatewayAddress="http://freesmsapi.com";
		$this->start();
		$this->skey=$params['skey'];
		$this->senderid=$params['senderid'];
		
		$this->setUserAgent('iPhone 4.0');
	}
	
	function __destruct()
	{
		$this->end();
	}
	public function login()
	{
	
		
			return true;
			
	}
	public function send($numbers,$message)
	{
		$to=implode(",",$numbers);
		$number=urlencode($to);
		$msg=urlencode($message);
		$skey=$this->skey;
		$senderid=urlencode($this->senderid);
		//http://s2.freesmsapi.com/messages/send?skey=da85c78a20xxxxxxxxxxxx&message=YOUR_MESSAGE&senderid=YOUR_SENDERID&recipient=MOBILE_NUMBER
		$out=$this->get("http://s2.freesmsapi.com/messages/send?skey=$skey&message=$msg&senderid=$senderid&recipient=$number&response=json");
		
		$out=json_decode($out);
		//print_r($out);
		if($out->response->error)
		{
			$this->setError($out->response->error->message);
			return false;
		}
		else
		{
			$this->setError(null);
			return true;
		}
		
		
	}
	
}




?>