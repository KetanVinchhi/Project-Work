<?php

include_once "class.gateway.php";
class gateway_freesms8_com extends gateway
{
	var $username;
	var $password;
		var $gatewayAddress;
	function __construct($params)
	{
	$this->gatewayAddres="http://www.freesms8.com";
		$this->start();
		$this->username=$params['username'];
		$this->password=$params['password'];
		
		$this->setUserAgent('iPhone 4.0');
	}
	
	function __destruct()
	{
		//$this->end();
	}
	public function login()
	{
	
		$username=$this->username;
		$password=$this->password;
		
		//******************************************************* NAVIGATE TO LOGIN PAGE TO ACQUIRE VIEWSTATE *******************************
		
		$out=$this->post("http://www.freesms8.com/Login.aspx","1=1");
		//we must match the value in <input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="GNY4uDQ0eugu9JwM4S6uxO2LtSMDziGnvfKgESAVm94=" />
		$pattern="/<input.*?name=\"__VIEWSTATE\".*?value=\"(.*?)\"/";
		$r=preg_match($pattern,$out,$matches);
		$viewstate=urlencode($matches[1]);
		
		//******************************************************* DO A POST WITH THE ACQUIRED VIEWSTATE - LOGIN *******************************
		//send a post request like __VIEWSTATE=GNY4uDQ0eugu9JwM4S6uxO2LtSMDziGnvfKgESAVm94%3D&__VIEWSTATEENCRYPTED=&ctl00%24Body%24UserName=9618881641&ctl00%24Body%24Password=1455&ctl00%24Body%24LoginButton=Login
		$postParams="__VIEWSTATE=$viewstate&__VIEWSTATEENCRYPTED=&ctl00%24Body%24UserName=$username&ctl00%24Body%24Password=$password&ctl00%24Body%24LoginButton=Login";
		
		$out=$this->post('http://www.freesms8.com/Login.aspx',$postParams);
		
		//******************************************************* CAPTURE ERROR IF PRESENT *******************************
		//if auth failed capture error message : <span id="ctl00_Body_ErrorLabel" style="color:Red;">Authentication failed.</span>
		$pattern="/<span.*?id=\"ctl00_Body_ErrorLabel\".*?>(.*?)<\/span>/";
		$r=preg_match($pattern,$out,$matches);
		if($r)
		{
			$msg=strip_tags($matches[1]);
			$this->setError($msg);
			return false;
			
		}
		else
		{
			return true;
		}
		
		

	
		
	
		
		
	}
	public function send($numbers,$message)
	{
	$to=implode(",",$numbers);
		
		$number=urlencode($to);
		$msg=urlencode($message);
		$username=$this->username;
		
		//******************************************************** NAVIGATE TO THE QUICK SMS PAGE TO GET VIEWSTATE ***************************************
		//http://www.freesms8.com/QuickSMS.aspx
		$out=$this->post("http://www.freesms8.com/QuickSMS.aspx","1=1");
		$pattern="/<input.*?name=\"__VIEWSTATE\".*?value=\"(.*?)\"/";
		$r=preg_match($pattern,$out,$matches);
		$viewstate=urlencode($matches[1]);
		
		//******************************************************* DO A POST WITH THE ACQUIRED VIEWSTATE - SEND THE MESSAGE *******************************
		//__EVENTTARGET=&__EVENTARGUMENT=&__VIEWSTATE=W5J%2BRI0sFPXM%2FBFak1YE%2BXV1%2BNg%2BJ%2F5uynbB%2Bo46CBE%3D&__VIEWSTATEENCRYPTED=&ctl00%24BodyPlaceHolder%24MobileNumber=9618881641&ctl00%24BodyPlaceHolder%24SMSText=test&ctl00%24BodyPlaceHolder%24SenderIdList=9618881641&ctl00%24BodyPlaceHolder%24HiddenSum=0&ctl00%24BodyPlaceHolder%24SendButton=Send+Now
		$postParams="__EVENTTARGET=&__EVENTARGUMENT=&__VIEWSTATE=$viewstate&__VIEWSTATEENCRYPTED=&ctl00%24BodyPlaceHolder%24MobileNumber=$number&ctl00%24BodyPlaceHolder%24SMSText=$msg&ctl00%24BodyPlaceHolder%24SenderIdList=$username$&ctl00%24BodyPlaceHolder%24HiddenSum=0&ctl00%24BodyPlaceHolder%24SendButton=Send+Now";
		$out=$this->post("http://www.freesms8.com/quickSMS.aspx",$postParams,"http://www.freesms8.com/quickSMS.aspx");
		
		//******************************************************* CAPTURE THE RESPONSE *******************************
		//<td align="left" style="font-family: Arial; color: Green; font-weight: bold; padding-left: 10px;">        Quick SMS sent Successfully - <a style="color: Blue;" href="quickSMS.aspx">Back to Quick SMS</a>
		$pattern="/<td.*?align=\"left\".*?Green.*?>(.*?)<a/s";
		$r=preg_match($pattern,$out,$matches);
		$out1=strip_tags($matches[1]);
		
		
		
		//******************************************************* CHECK THE RESPONSE *******************************
		if(!preg_match("/successfully/i",$out1))
		{
		
		//******************************************************* CAPTURE ERROR MESSAGE  *******************************
		//<span id="ctl00_BodyPlaceHolder_MessageLabel"><font color="Red">Invalid phone number.</font></span>
		$pattern="/<span.*?id=\"ctl00_BodyPlaceHolder_MessageLabel\">(.*?)<\/span>/";
		$r=preg_match($pattern,$out,$matches);
		$out=strip_tags($matches[1]);
		$this->setError($out);
		return false;
		}
		else
		{
		//$out=$this->post("http://www.freesms8.com/QuickSent.aspx","1=1");
		
		return true;
		$this->setError($out1);
		}
	}
	
}




?>