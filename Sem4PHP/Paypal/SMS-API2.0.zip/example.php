<?php
error_reporting(E_ALL^E_NOTICE);
ob_implicit_flush(true);

//If you get Fatal error: Call to undefined function curl_init() , Then you need to enable the curl extension in php.ini

$gateway='freesmsapi_com'; // supported gateways 160by2_com,freesms8_com, freesmsapi_com
// group message support
$to=array('10digitnumber1','10digitnumber2');
$message="your message";


$info=array();
$info['username']="";
$info['password']='';
/*
//other info required by the gateway
$info['skey']="";
$info['senderid']="";
*/
include_once "gateway_{$gateway}.php";

$gatewayClass="gateway_{$gateway}";
$smsapp=new $gatewayClass($info);
//$smsapp->setProxy('myproxy:myport');
//$smsapp->checkConnectivity();


echo "Logging in  ...  ";
$result=$smsapp->login();
if($result)
{

echo "Sending SMS ... ";
$result=$smsapp->send($to,$message);

if($result==true)
{
	echo "Message sent";
}
else
{	
	echo "Error encountered : ".$smsapp->getLastError();
}
}
else
{
	echo "Login error :".$smsapp->getLastError();
}
?>