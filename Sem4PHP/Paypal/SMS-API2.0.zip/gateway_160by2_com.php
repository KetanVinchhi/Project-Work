<?php

include_once "class.gateway.php";
class gateway_160by2_com extends gateway
{
	var $username;
	var $password;
	var $gatewayAddress;
	
	function __construct($params)
	{
	
		$this->gatewayAddress="http://www.160by2.com";
		$this->start();
		$this->username=$params['username'];
		$this->password=$params['password'];
		
		$this->setUserAgent('iPhone 4.0');
	}
	
	function __destruct()
	{
		$this->end();
	}
	public function login()
	{
	
		$username=$this->username;
		$password=$this->password;
		$out=$this->post("http://m.160by2.com/LoginCheck.asp?l=1&txt_msg=&mno=","txtUserName=$username&txtPasswd=$password&RememberMe=Yes&cmdSubmit=Login");
		$pattern="/MyMenu.asp\?Msg=(.+?)&/";
		$r=preg_match($pattern,$out,$matches);
		
		if(!$r)
		{
			$pattern="/index.asp\?ErrMsg=(.+?)\n/";
			preg_match($pattern,$out,$matches);
			$msg=trim($matches[1]);
			$this->setError(urldecode($msg));
			return false;
		}
		else
		{
		$id=trim($matches[1]);
		$this->setData('id',$id);
		return true;
		}
		
		
	}
	public function send($numbers,$message)
	{
		$to=implode(",",$numbers);
		$number=urlencode($to);
		$msg=urlencode($message);
		$id=$this->getData('id');
		$out1=$this->post("http://m.160by2.com/SaveCompose.asp?l=1","txt_mobileno=$number&txt_msg=$msg&cmdSend=Send+SMS&TID=&T_MsgId=&Msg=$id");
		$pattern = '/\<table.+?\>(.+)\<\/table/s';
		preg_match($pattern, $out1, $matches);
		$out=trim(strip_tags(@$matches[1]));
		if(count($matches)<1)
		{
		$pattern="/\<div.+?background:.+?yellow.+?\>(.+?)\<\/div\>/s";
		preg_match($pattern,$out1,$matches);
		$out=trim(strip_tags($matches[1]));
		
		}
		

		if(!preg_match("/successfully/i",$out))
		{
		$this->setError($out);
		return false;
		}
		else
		{
		return true;
		$this->setError("No errors");
		}
	}
	
}




?>